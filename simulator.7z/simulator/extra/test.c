#include <stdio.h> /* printf, sprintf */
#include <stdlib.h> /* exit, atoi, malloc, free */

#include <string.h> /* memcpy, memset */
#include <time.h>

void delay(unsigned int mseconds)
{
    clock_t goal = mseconds + clock();
    while (goal > clock());
}
void main()
{
char *message = malloc(4);
char *msg = malloc(126);
strcpy(message,"hello world!!");

printf("%s",message);


free(message);


}
