#include <stdio.h> /* printf, sprintf */
#include <stdlib.h> /* exit, atoi, malloc, free */
#include <unistd.h> /* read, write, close */
#include <string.h> /* memcpy, memset */
#include <resolv.h>
#include "openssl/ssl.h"
#include "openssl/err.h"
#include <sys/types.h>
#include <sys/socket.h> /* socket, connect */
#include <netdb.h> /* struct hostent, gethostbyname */
#include <netinet/in.h> /* struct sockaddr_in, struct sockaddr */
#include <arpa/inet.h>

#define FAIL    -1



void error(const char * msg)
{
	perror(msg);
	exit(0);
}

/*---------------------------------------------------------------------*/
/*--- OpenConnection - create socket and connect to server.         ---*/
/*---------------------------------------------------------------------*/
int OpenConnection(const char *hostname, int port)
{   int sd;
	//struct hostent *host;
	struct sockaddr_in addr;

	sd = socket(AF_INET, SOCK_STREAM, 0);
	if (sd < 0) 
	{
		error("ERROR opening socket");   
	}

	bzero(&addr, sizeof(addr));
	if ( (inet_pton(AF_INET,hostname,&addr.sin_addr)) == -1 )
	{
		fprintf(stderr,"ERROR converting IP\n");
		exit(0);
	}

	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);
	//bcopy((char *)host->h_addr, 
	// (char *)&addr.sin_addr.s_addr,
	// host->h_length);
	//addr.sin_addr.s_addr = *(long*)(host->h_addr);
	if ( connect(sd, (struct sockaddr*)&addr, sizeof(struct sockaddr)) != 0 )
	{
		error("ERROR connecting");
	}
	return sd;
}

/*---------------------------------------------------------------------*/
/*--- InitCTX - initialize the SSL engine.                          ---*/
/*---------------------------------------------------------------------*/
SSL_CTX* InitCTX(void)
{   
	const SSL_METHOD *method;
	SSL_CTX *ctx;

	(void)SSL_library_init();
	//init_openssl_library();
	OpenSSL_add_all_algorithms();		/* Load cryptos, et.al. */
	OpenSSL_add_all_ciphers();
	OpenSSL_add_all_digests();
	SSL_load_error_strings();			/* Bring in and register error messages */
	method = SSLv23_client_method();		/* Create new client-method instance */
	//printf("i am here\n");
	ctx = SSL_CTX_new(method);			/* Create new context */
	//printf("now here\n");
	if ( ctx == NULL )
	{
		ERR_print_errors_fp(stderr);
		abort();
	}
	//printf("should be here\n");
	return ctx;
}

/*---------------------------------------------------------------------*/
/*--- ShowCerts - print out the certificates.                       ---*/
/*---------------------------------------------------------------------*/
void ShowCerts(SSL* ssl)
{   X509 *cert;
	char *line;

	cert = SSL_get_peer_certificate(ssl);	/* get the server's certificate */
	if ( cert != NULL )
	{
		printf("Server certificates:\n");
		line = X509_NAME_oneline(X509_get_subject_name(cert), 0, 0);
		printf("Subject: %s\n", line);
		free(line);							/* free the malloc'ed string */
		line = X509_NAME_oneline(X509_get_issuer_name(cert), 0, 0);
		printf("Issuer: %s\n", line);
		free(line);							/* free the malloc'ed string */
		X509_free(cert);					/* free the malloc'ed certificate copy */
	}
	else
		printf("No certificates.\n");
}

/*---------------------------------------------------------------------*/
/*--- Send_Request - send the request                               ---*/
/*---------------------------------------------------------------------*/
void Send_Request(char * message, SSL *ssl)
{
	int total,sent,bytes;
	total = strlen(message);
	sent = 0;
	do {
		bytes = SSL_write(ssl,message+sent,total-sent);
		if (bytes < 0)
			error("ERROR writing message to socket");
		if (bytes == 0)
			break;
		sent+=bytes;
	} while (sent < total);

}

/*---------------------------------------------------------------------*/
/*--- Receive_Response - receive the reponse                        ---*/
/*---------------------------------------------------------------------*/
void  Receive_Response(SSL *ssl)
{
	int total,received,bytes;
	char response[4096*8];
//        printf("@@ %d\n",sizeof(response)); 
	memset(response,0,sizeof(response));
	total = sizeof(response)-1;
	received = 0;
	do {
		bytes = SSL_read(ssl,response+received,total-received);
		if (bytes < 0)
			error("ERROR reading response from socket");
		if (bytes == 0)
			break;
		received+=bytes;
	} while (received < total);

	printf("Response:size= %d n%s\n",sizeof(response),response);
	if (received == total)
		error("ERROR storing complete response from socket");
	
}


/*---------------------------------------------------------------------*/
/*--- main - create SSL context and connect                         ---*/
/*---------------------------------------------------------------------*/

int main (int argc, char * argv[])
{
	SSL_CTX *ctx;
	int sockfd;
	SSL *ssl;
        char *message = malloc(4096),*response;
//	int bytes, sent, received, total, message_size;
	char *hostname,*portnum;

	/*if ( argc !=3 )
	  {
	  printf("Error, Usage: %s <hostname> <portnum>\n", argv[0]);
	  exit(0);
	  }*/

	hostname = "172.17.9.54";
	portnum = "443";


	ctx = InitCTX();
	sockfd = OpenConnection(hostname, atoi(portnum));
	//printf("here\n");
	ssl = SSL_new(ctx);		//Watch for pssible error!! (SSL_CTX_new?)
	//printf("now here\n");

	/*if(! SSL_CTX_load_verify_locations(ctx, "~/home/admin/savya/simulator/savya2.cer", NULL))
	  {
	  printf("Error: %s\n", ERR_reason_error_string(ERR_get_error()));
	  exit(0);
	  }*/

	SSL_set_fd(ssl,sockfd);
	//SSL_set_mode(ssl, SSL_MODE_AUTO_RETRY);
	if (SSL_connect (ssl) == FAIL)
	{
		ERR_print_errors_fp(stderr);	//other options..?
		exit(0);
	}


	message = strcpy(message,"GET /fes-bin/public/portal/all/js/propalms.js HTTP/1.0\r\n");
	strcat(message,"Accept:*/*\r\n");
	strcat(message,"Accept-Encoding:gzip, deflate, sdch, br\r\n");
	strcat(message,"Accept-Language:en-US,en;q=0.8\r\n");
	strcat(message,"Connection:keep-alive\r\n");
	strcat(message,"Cookie:httpOnly; httpOnly; httpOnly; httpOnly; httpOnly\r\n");
	strcat(message,"Host:172.17.9.54\r\n");
//	strcat(message,"If-Modified-Since:Wed, 31 May 2017 14:47:05 GMT\r\n");
	strcat(message,"If-None-Match:\"1cb4f-550d2fe65ec40-gzip\"\r\n");
	strcat(message,"Referer:https://172.17.9.54/fes-bin/public/portal/act/loginPage.htm\r\n");
	strcat(message,"User-Agent:Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36\r\n");
	strcat(message,"\r\n");
	
	/* send the request */
	Send_Request(message,ssl);

	/* receive the response */
	Receive_Response(ssl);


	close(sockfd);									/* close socket */
	SSL_CTX_free(ctx);								/* release context */
	free(message);
}
