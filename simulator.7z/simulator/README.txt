-------------------------------- HTTP INVALID DATA SIMULATOR --------------------------------

Note: Currently only support for linux OS. windows support will be released soon.

Steps:
-Open simulator.py in a text editor.
-search for varibales "host" and "port" and set them accordingly.
-save and exit.
-Open request folder and save a valid request in a txt file with a heading in first line if needed.
-Run simulator.py file using python3 on a linux OS.
-Choose between the two modes as needed.
-Simulaions will be performed. Make sure your the specified host is reachable by system.
-Results will be result folder and Response in response folder.
-If Mannual Mode was selected result will be in Result.txt.

